from __future__ import absolute_import

import os

import sys 
sys.path.insert(0,'./')
from got10k.datasets import *

from siamfc import TrackerSiamFC


if __name__ == '__main__':
    # root_dir = os.path.expanduser('/home/wangxiao/Documents/rgb_event_tracking_benchmark/siamfc-pytorch/data/GOT-10k')
    # seqs = GOT10k(root_dir, subset='train', return_meta=True)

    root_dir = os.path.expanduser('/home/wangxiao/Documents/rgb_event_tracking_benchmark/siamfc-pytorch/data/NfS_dataset')
    seqs = NfSEvent(root_dir, subset='train', return_meta=False)
    
    # import pdb 
    # pdb.set_trace() 
    
    tracker = TrackerSiamFC()
    tracker.train_over(seqs)
